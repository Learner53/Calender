$(function() { 
  var $calendar = $('#calendar');
  $calendar.fullCalendar({
    header: false,
    resourceAreaWidth: 230,
    aspectRatio: 1.5,
    scrollTime: '00:00',
    center: 'title',
    defaultView: 'agendaWeek',
    columnFormat: 'DD ddd',
    defaultDate: moment().format("YYYY-MM-DD"),

    viewRender: (view) => {
      let date
      switch (view.type) {
        case 'agendaDay':
          date = view.start.format('DD dddd YYYY')
          break
        case 'agendaWeek':
          date = view.start.format('MMMM')
          break
        case 'month':
          date = view.start.format('MMMM')
          break
      }
      $('#start-date').text(view.start.format('DD'));
      $('#end-date').text(view.end.format('DD MMM YYYY'));

    },
  });
  
  // Next/Prev buttons
  $("#next").on('click', function() {
    $calendar.fullCalendar('next')
  });
  $("#prev").on('click', function() {
    $calendar.fullCalendar('prev')
  });
  
  // Select
  $("#select").on('change', function (event) {
    $calendar.fullCalendar('changeView', this.value)
  })
});